/*
 * File Name:               lab5ExC.cpp
 * Course:                  ENSF 614 - Fall 2021
 * Lab # and Assignment #:  Lab 5 Exercise C
 * Lab section:             B01
 * Completed by:            Aastha Patel, Bhavyai Gupta
 * Submission Date:         October 26, 2021
 */

#include "graphicsWorld.h"

using namespace std;

int main(int argc, char const *argv[])
{
    GraphicsWorld::run();
    return 0;
}
